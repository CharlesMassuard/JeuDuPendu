# !/bin/bash

cd AutresJeux/SpaceInvaders
sh start.sh
cd ../..