# !/bin/bash

cd AutresJeux/Demineur
sh start.sh
cd ../..